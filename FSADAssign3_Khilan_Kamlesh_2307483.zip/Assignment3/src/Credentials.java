
public class Credentials {
    public static final String USERNAME = "postgres";
    public static final String PASSWORD = "khilzkamlesh";
    public static final String URL = "jdbc:postgresql://localhost:5432/Music";

    public static final String HOST = "127.0.0.1"; //localhost
    public static final int PORT = 80;
}
