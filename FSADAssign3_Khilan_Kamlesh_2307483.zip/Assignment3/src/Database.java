import java.sql.*;

public class Database {

    public int getTitles(String artistName) {
        int titleNum = 0;
        try {
            Class.forName("org.postgresql.Driver");

            Connection con = DriverManager.getConnection(Credentials.URL, Credentials.USERNAME, Credentials.PASSWORD);

            String sql = "SELECT artistid from artist WHERE name = ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.clearParameters();
            pstmt.setString(1, artistName);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int artistId = rs.getInt(1);

                sql = "SELECT * FROM album WHERE artistId = ?";
                pstmt = con.prepareStatement(sql);
                pstmt.clearParameters();
                pstmt.setInt(1, artistId);
                ResultSet rs2 = pstmt.executeQuery();
                while (rs2.next()) {
                    titleNum++;
                }
                rs2.close();
            }
            rs.close();
            pstmt.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return titleNum;
    }

    // This method establishes a DB connection & returns a boolean status
    public boolean establishDBConnection() {
        //Implement this method
        //5 sec timeout
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection(Credentials.URL, Credentials.USERNAME, Credentials.PASSWORD);
            return con.isValid(5);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }
}